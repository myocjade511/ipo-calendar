#!/usr/bin/env python3
"""
Swoogo API Helper Script

Usage:
  python swoogo_api.py <command> [args]

Commands:
  list-events                    List all events
  get-event --id EVENT_ID        Get event details
  create-event --name NAME ...   Create a new event
  update-event --id ID ...       Update an event
  delete-event --id ID           Delete an event
  list-contacts                  List all contacts
  create-contact --email EMAIL   Create a new contact
  list-orders                    List all orders
  list-folders                   List all folders
  list-promo-codes               List all promo codes
"""

import os
import json
import sys
import urllib.request
import urllib.error

BASE_URL = "https://api.swoogo.com/api/v1"

def get_api_key():
    key = os.environ.get("SWOOGO_API_KEY")
    if not key:
        print("Error: SWOOGO_API_KEY environment variable is not set")
        sys.exit(1)
    return key

def api_request(method, path, data=None):
    key = get_api_key()
    url = f"{BASE_URL}{path}"
    headers = {
        "Api-Key": key,
        "Content-Type": "application/json",
        "User-Agent": "OpenClaw-SwoogoSkill/1.0"
    }
    
    body = json.dumps(data).encode() if data else None
    
    req = urllib.request.Request(url, data=body, headers=headers, method=method)
    try:
        with urllib.request.urlopen(req, timeout=30) as resp:
            return json.loads(resp.read().decode())
    except urllib.error.HTTPError as e:
        error_body = e.read().decode() if e.fp else "{}"
        try:
            error_json = json.loads(error_body)
        except:
            error_json = {"error": error_body}
        print(f"HTTP {e.code}: {error_json}")
        sys.exit(1)
    except urllib.error.URLError as e:
        print(f"Connection error: {e.reason}")
        sys.exit(1)

def cmd_list_events():
    result = api_request("GET", "/events")
    events = result if isinstance(result, list) else result.get("events", result.get("data", []))
    print(json.dumps(events, indent=2))
    print(f"\nTotal: {len(events)} events")

def cmd_get_event(args):
    event_id = args.get("id") or args.get("event_id")
    if not event_id:
        print("Usage: get-event --id EVENT_ID")
        sys.exit(1)
    result = api_request("GET", f"/events/{event_id}")
    print(json.dumps(result, indent=2))

def cmd_create_event(args):
    required = ["name", "start_date", "start_time", "end_date", "end_time", "timezone"]
    missing = [f for f in required if f not in args or not args[f]]
    if missing:
        print(f"Missing required fields: {', '.join(missing)}")
        print("Usage: create-event --name NAME --start_date YYYY-MM-DD --start_time HH:MM:SS --end_date YYYY-MM-DD --end_time HH:MM:SS --timezone TZ")
        sys.exit(1)
    
    payload = {k: args[k] for k in required}
    optional = ["close_date", "close_time", "folder_id", "display_url"]
    for k in optional:
        if k in args and args[k]:
            payload[k] = args[k]
    
    result = api_request("POST", "/events/create", payload)
    print(json.dumps(result, indent=2))
    print("\n✅ Event created")

def cmd_update_event(args):
    event_id = args.get("id")
    if not event_id:
        print("Usage: update-event --id EVENT_ID [--name NAME] ...")
        sys.exit(1)
    
    fields = ["name", "start_date", "start_time", "end_date", "end_time", "timezone",
              "close_date", "close_time", "folder_id", "display_url"]
    payload = {k: args[k] for k in fields if k in args and args[k]}
    if not payload:
        print("No fields to update")
        sys.exit(1)
    
    result = api_request("PUT", f"/events/update/{event_id}", payload)
    print(json.dumps(result, indent=2))
    print("\n✅ Event updated")

def cmd_delete_event(args):
    event_id = args.get("id")
    if not event_id:
        print("Usage: delete-event --id EVENT_ID")
        sys.exit(1)
    result = api_request("DELETE", f"/events/{event_id}")
    print(f"✅ Event {event_id} deleted")
    if result:
        print(json.dumps(result, indent=2))

def cmd_list_contacts():
    result = api_request("GET", "/contacts")
    contacts = result if isinstance(result, list) else result.get("contacts", result.get("data", []))
    print(json.dumps(contacts, indent=2))
    print(f"\nTotal: {len(contacts)} contacts")

def cmd_create_contact(args):
    email = args.get("email")
    if not email:
        print("Usage: create-contact --email EMAIL [--first_name FNAME --last_name LNAME]")
        sys.exit(1)
    
    payload = {"email": email}
    for k in ["first_name", "last_name", "phone"]:
        if k in args and args[k]:
            payload[k] = args[k]
    
    result = api_request("POST", "/contacts/create", payload)
    print(json.dumps(result, indent=2))
    print("\n✅ Contact created")

def cmd_list_orders():
    result = api_request("GET", "/orders")
    orders = result if isinstance(result, list) else result.get("orders", result.get("data", []))
    print(json.dumps(orders, indent=2))
    print(f"\nTotal: {len(orders)} orders")

def cmd_list_folders():
    result = api_request("GET", "/folders")
    items = result if isinstance(result, list) else result.get("folders", result.get("data", []))
    print(json.dumps(items, indent=2))
    print(f"\nTotal: {len(items)} folders")

def cmd_list_promo_codes():
    result = api_request("GET", "/promo-codes")
    items = result if isinstance(result, list) else result.get("promo_codes", result.get("data", []))
    print(json.dumps(items, indent=2))
    print(f"\nTotal: {len(items)} promo codes")

def parse_args():
    args = {}
    i = 2  # skip script name and command
    while i < len(sys.argv):
        if sys.argv[i].startswith("--"):
            key = sys.argv[i][2:]
            if i + 1 < len(sys.argv) and not sys.argv[i+1].startswith("--"):
                args[key] = sys.argv[i+1]
                i += 2
            else:
                args[key] = True
                i += 1
        else:
            i += 1
    return args

COMMANDS = {
    "list-events": cmd_list_events,
    "get-event": cmd_get_event,
    "create-event": cmd_create_event,
    "update-event": cmd_update_event,
    "delete-event": cmd_delete_event,
    "list-contacts": cmd_list_contacts,
    "create-contact": cmd_create_contact,
    "list-orders": cmd_list_orders,
    "list-folders": cmd_list_folders,
    "list-promo-codes": cmd_list_promo_codes,
}

if __name__ == "__main__":
    if len(sys.argv) < 2 or sys.argv[1] not in COMMANDS:
        print("Swoogo API Helper")
        print("Usage: python swoogo_api.py <command> [--key value ...]")
        print("\nCommands:")
        for cmd in sorted(COMMANDS.keys()):
            print(f"  {cmd}")
        sys.exit(1)
    
    args = parse_args()
    COMMANDS[sys.argv[1]](args)
