---
name: swoogo-skill
description: Manage Swoogo events, registration types, sessions, packages, orders, contacts, tickets, promo codes, folders, and questions via the Swoogo REST API. Activate for event management, registration setup, ticket sales, and attendee management.
version: 1.0.0
license: Proprietary
metadata:
  openclaw:
    requires:
      env: ["SWOOGO_API_KEY"]
      bins: ["curl"]
    primaryEnv: SWOOGO_API_KEY
    emoji: "🎫"
---

# Swoogo API Skill

Manage events, registrations, tickets, and attendees via the Swoogo REST API.

Base URL: `https://api.swoogo.com/api/v1`

Authentication: API key passed in the `Api-Key` header.

## Required Credentials

- `SWOOGO_API_KEY` — Your Swoogo API key. Generate from your Swoogo account settings.

## Endpoints

### Events

| Method | Endpoint | Description |
|--------|----------|-------------|
| `POST` | `/events/create` | Create a new event (draft by default) |
| `PUT` | `/events/update/{event_id}` | Update an existing event |
| `GET` | `/events` | List all events |
| `GET` | `/events/{event_id}` | Get event details |
| `DELETE` | `/events/{event_id}` | Delete an event |

**Create Event — required fields:**
- `name` — Event name
- `start_date` — Start date (YYYY-MM-DD)
- `start_time` — Start time (HH:MM:SS in event timezone)
- `end_date` — End date (YYYY-MM-DD)
- `end_time` — End time (HH:MM:SS in event timezone)
- `timezone` — Timezone identifier (e.g., `US/Eastern`, `Europe/London`, `Asia/Tokyo`)

**Create Event — optional fields:**
- `close_date` / `close_time` — When registration closes
- `folder_id` — Organize event in a folder
- `display_url` — Registration page URL slug

### Registration Types

| Method | Endpoint | Description |
|--------|----------|-------------|
| `POST` | `/events/{event_id}/registration-types` | Add registration type to an event |
| `GET` | `/events/{event_id}/registration-types` | List registration types for an event |

### Sessions

| Method | Endpoint | Description |
|--------|----------|-------------|
| `POST` | `/sessions/create` | Create a new session |
| `GET` | `/sessions` | List all sessions |

### Packages

| Method | Endpoint | Description |
|--------|----------|-------------|
| `POST` | `/packages/create` | Create a new package |
| `GET` | `/packages` | List all packages |

### Orders

| Method | Endpoint | Description |
|--------|----------|-------------|
| `POST` | `/orders` | Create a new order |
| `GET` | `/orders` | List all orders |

### Contacts (Attendees)

| Method | Endpoint | Description |
|--------|----------|-------------|
| `POST` | `/contacts/create` | Create a new contact |
| `GET` | `/contacts` | List all contacts |

### Tickets

| Method | Endpoint | Description |
|--------|----------|-------------|
| `POST` | `/tickets` | Create a new ticket |
| `GET` | `/tickets` | List all tickets |

### Promo Codes

| Method | Endpoint | Description |
|--------|----------|-------------|
| `POST` | `/promo-codes` | Create a new promo code |
| `GET` | `/promo-codes` | List all promo codes |

### Folders

| Method | Endpoint | Description |
|--------|----------|-------------|
| `POST` | `/folders` | Create a new folder |
| `GET` | `/folders` | List all folders |

### Questions

| Method | Endpoint | Description |
|--------|----------|-------------|
| `POST` | `/questions` | Create a new question |
| `GET` | `/questions` | List all questions |

## Workflow

All requests use the `Api-Key` header for authentication and send/receive JSON.

### Create an Event

```bash
curl -X POST https://api.swoogo.com/api/v1/events/create \
  -H "Api-Key: $SWOOGO_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Annual Conference 2026",
    "start_date": "2026-06-15",
    "start_time": "09:00:00",
    "end_date": "2026-06-17",
    "end_time": "17:00:00",
    "timezone": "US/Eastern",
    "display_url": "annual-conference-2026"
  }'
```

### List Events

```bash
curl "https://api.swoogo.com/api/v1/events" \
  -H "Api-Key: $SWOOGO_API_KEY"
```

### Create a Registration Type for an Event

```bash
curl -X POST "https://api.swoogo.com/api/v1/events/{event_id}/registration-types" \
  -H "Api-Key: $SWOOGO_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Early Bird",
    "price": 99.00
  }'
```

### Create an Order (Ticket Purchase)

```bash
curl -X POST https://api.swoogo.com/api/v1/orders \
  -H "Api-Key: $SWOOGO_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{
    "event_id": 12345,
    "contact_id": 67890,
    "items": [
      {
        "registration_type_id": 111,
        "quantity": 2,
        "price": 99.00
      }
    ]
  }'
```

## Helper Script

Use `scripts/swoogo_api.py` for convenience commands:

```bash
python scripts/swoogo_api.py <command> [args]
```

See the script file for the full list of supported commands.

## Pagination

List endpoints support pagination via `page` and `per_page` query parameters (default 20, max 100).

## Failure Handling

| Error | Meaning |
|-------|---------|
| `401 Unauthorized` | Invalid or missing API key |
| `404 Not Found` | Resource doesn't exist |
| `422 Unprocessable Entity` | Validation error (check required fields) |

## Output Format

Return results in structured JSON confirming the operation with relevant IDs and URLs.
