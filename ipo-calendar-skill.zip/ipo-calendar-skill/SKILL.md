---
name: ipo-calendar-skill
description: Deploy the IPO Calendar website — a 6-month IPO pipeline tracker with live data scraping, filterable sections, and dark theme. Publishes to GitHub + Vercel as a static site.
version: 1.1.0
license: Proprietary
metadata:
  openclaw:
    requires:
      env: ["GITHUB_TOKEN", "VERCEL_TOKEN"]
      bins: ["curl", "git"]
    primaryEnv: GITHUB_TOKEN
    emoji: "📊"
---

# IPO Calendar Skill

Deploy and update the IPO Radar — a fully self-contained 6-month IPO tracker that shows confirmed pricings, scheduled offerings, projected IPO dates, recently priced deals, and SEC filings awaiting pricing.

## What It Does

- **Static HTML/CSS/JS site** — no server, no build step, just one file
- **6-month pipeline**: May through November 2026 with projected dates based on S-1 filings
- **Filter buttons**: All / This Week / June / Q3 / Filed Only / Recently Priced
- **Auto-refresh**: Click "Refresh Data" to retry live scraping
- **Color-coded returns**: green for up, red for down
- **Dark theme**: desktop + mobile responsive

## Live URL

https://ipo-calendar-gules.vercel.app

## Files

The site is a single-page static HTML file with embedded CSS and JS. The `vercel.json` configures it for Vercel static hosting.

- `index.html` — Full IPO calendar (20KB, all CSS + JS inline)
- `vercel.json` — Vercel config (static site, no build)

## Deployment Steps

### 1. Create GitHub Repo

```bash
gh repo create ipo-calendar --public --description "6-month IPO pipeline tracker" --auto-init
# or via API
curl -X POST https://api.github.com/user/repos \
  -H "Authorization: Bearer $GITHUB_TOKEN" \
  -H "Accept: application/vnd.github+json" \
  -d '{"name":"ipo-calendar","private":false,"description":"IPO Radar — 6-month IPO pipeline tracker","auto_init":true}'
```

### 2. Create Vercel Project

```bash
curl -X POST "https://api.vercel.com/v10/projects?teamId=$VERCEL_TEAM_ID" \
  -H "Authorization: Bearer $VERCEL_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"name":"ipo-calendar","framework":null}'
```

### 3. Link GitHub to Vercel

```bash
curl -X POST "https://api.vercel.com/v10/projects/$PROJECT_ID/link?teamId=$VERCEL_TEAM_ID" \
  -H "Authorization: Bearer $VERCEL_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"type":"github","repo":"myocjade511/ipo-calendar"}'
```

### 4. Push Files

```bash
git clone https://myocjade511:$GITHUB_TOKEN@github.com/myocjade511/ipo-calendar.git /tmp/ipo-calendar
cp index.html vercel.json /tmp/ipo-calendar/
cd /tmp/ipo-calendar
git config user.email "myocjade511@gmail.com"
git config user.name "myocjade511"
git add .
git commit -m "IPO Radar v5 — 6-month pipeline with working filters"
git push origin main
```

### 5. Verify Deployment

```bash
curl -s "https://ipo-calendar-gules.vercel.app" | head -5
# Should show: <!DOCTYPE html> with IPO Radar title
```

### 6. Save Project Metadata

Save to `projects/ipo-calendar/project-info.json`:

```json
{
  "projectName": "ipo-calendar",
  "github": {
    "owner": "myocjade511",
    "repo": "ipo-calendar",
    "fullName": "myocjade511/ipo-calendar",
    "visibility": "public"
  },
  "vercel": {
    "projectId": "prj_knmgJZHt19Jsz8SqwAnl5MB1xlfp",
    "projectName": "ipo-calendar",
    "scope": "Jade's projects",
    "teamId": "team_xvFesmiaWI9RkZvfYuMNbDtU"
  },
  "urls": {
    "live": "https://ipo-calendar-gules.vercel.app",
    "github": "https://github.com/myocjade511/ipo-calendar"
  }
}
```

## Updating

To update the 5+ month projection data, edit the `generateCalendar()` function in `index.html` — the `cal.june`, `cal.july`, `cal.august`, `cal.september`, `cal.october`, `cal.november` arrays. Push changes to GitHub, Vercel auto-deploys.

## Known Config

| Item | Value |
|------|-------|
| GitHub user | `myocjade511` |
| GitHub email | `myocjade511@gmail.com` |
| Vercel user | `myocjade511-3641` |
| Vercel team | `Jade's projects` |
| Vercel team ID | `team_xvFesmiaWI9RkZvfYuMNbDtU` |
| Live URL | https://ipo-calendar-gules.vercel.app |
| GitHub URL | https://github.com/myocjade511/ipo-calendar |
