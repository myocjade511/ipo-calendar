---
name: deployment-skill
description: End-to-end project deployment — create GitHub repos, set up Vercel projects, link them, push static files, and deploy live. Triggers on "deploy to vercel", "publish to vercel", "setup github & vercel".
version: 2.0.0
license: Proprietary
metadata:
  openclaw:
    requires:
      env: ["GITHUB_TOKEN", "VERCEL_TOKEN"]
      bins: ["git", "curl"]
    primaryEnv: GITHUB_TOKEN
    emoji: "🚀"
---

# Deployment Skill

Set up GitHub repositories + Vercel projects, link them, push files, and deploy live. Supports static sites, HTML apps, and any framework Vercel supports.

## Required Credentials

- `GITHUB_TOKEN` — GitHub personal access token with `repo` scope
- `VERCEL_TOKEN` — Vercel API token from [Account Settings → Tokens](https://vercel.com/account/tokens)

## Workflow

### 1. Define Project

Get the project name from the user. Clean it (lowercase, dashes). Suggest a cleaned name if needed.

### 2. Check GitHub Access

```bash
curl -s -H "Authorization: Bearer $GITHUB_TOKEN" "https://api.github.com/user"
```

If fails: ask user to refresh or configure their token.

### 3. Check Vercel Access

```bash
curl -s -H "Authorization: Bearer $VERCEL_TOKEN" "https://api.vercel.com/v2/user"
```

If fails: ask user to refresh or configure their token.

### 4. List Vercel Teams

```bash
curl -s -H "Authorization: Bearer $VERCEL_TOKEN" "https://api.vercel.com/v2/teams"
```

- If only one team → auto-select
- If multiple → ask user which one

### 5. Create GitHub Repo

```bash
curl -s -X POST -H "Authorization: Bearer $GITHUB_TOKEN" \
  -H "Accept: application/vnd.github+json" \
  -d '{"name":"REPO_NAME","private":false,"description":"DESCRIPTION","auto_init":true}' \
  "https://api.github.com/user/repos"
```

Default: **public**. Ask user if they want private.

### 6. Create Vercel Project

```bash
curl -s -X POST -H "Authorization: Bearer $VERCEL_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"name":"PROJECT_NAME","framework":null}' \
  "https://api.vercel.com/v10/projects?teamId=TEAM_ID"
```

### 7. Link GitHub → Vercel

```bash
curl -s -X POST -H "Authorization: Bearer $VERCEL_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"type":"github","repo":"OWNER/REPO_NAME"}' \
  "https://api.vercel.com/v10/projects/PROJECT_ID/link?teamId=TEAM_ID"
```

### 8. Push Files to GitHub

```bash
git clone https://USERNAME:$GITHUB_TOKEN@github.com/OWNER/REPO.git /tmp/REPO
# copy files
cp /path/to/files/* /tmp/REPO/
cd /tmp/REPO
git config user.email "USER@email.com"
git config user.name "USERNAME"
git add .
git commit -m "Initial deployment"
git push origin main
```

### 9. Trigger Vercel Deploy (Direct API — fallback if auto-deploy doesn't trigger)

```bash
curl -s -X POST -H "Authorization: Bearer $VERCEL_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"name":"PROJECT_NAME","target":"production","files":[{"file":"index.html","data":"BASE64_DATA"}]}' \
  "https://api.vercel.com/v13/deployments?teamId=TEAM_ID"
```

Vercel may return preview URL aliases. The production alias should be the main URL.

## Project Metadata

After successful setup, save to `projects/[project-name]/project-info.json`:

```json
{
  "projectName": "my-project",
  "cleanedName": "my-project",
  "github": {
    "owner": "username",
    "repo": "my-project",
    "fullName": "username/my-project",
    "visibility": "public",
    "isOrganization": false,
    "isNew": true
  },
  "vercel": {
    "projectId": "prj_...",
    "projectName": "my-project",
    "scope": "Team Name",
    "teamId": "team_...",
    "isNew": true
  },
  "urls": {
    "live": "https://project-name.vercel.app",
    "github": "https://github.com/username/my-project"
  },
  "linkedAt": "YYYY-MM-DD",
  "status": "ready"
}
```

## Your Known Config

**GitHub:**
- Username: `myocjade511`
- Email: `myocjade511@gmail.com`
- Token: stored in env `GITHUB_TOKEN`

**Vercel:**
- Username: `myocjade511-3641`
- Email: `myocjade511@gmail.com`
- Token: stored in env `VERCEL_TOKEN`
- Team ID: `team_xvFesmiaWI9RkZvfYuMNbDtU`
- Team Name: `Jade's projects`

## Deployed Projects

| Project | GitHub | Live URL |
|---------|--------|----------|
| IPO Calendar | `myocjade511/ipo-calendar` | https://ipo-calendar-gules.vercel.app |

## Failure Handling

| Error | Cause | Resolution |
|-------|-------|------------|
| 401 on GitHub | Token invalid/expired | Regenerate at github.com/settings/tokens |
| 401 on Vercel | Token invalid/expired | Regenerate at vercel.com/account/tokens |
| Repo creation fails | Name taken or invalid chars | Try different name |
| Vercel project creation fails | API version mismatch | Try v9 or v10 endpoint |
| Link fails | Git provider not connected in Vercel | User must connect GitHub in Vercel dashboard |
| Push fails | Auth expired or wrong branch | Clone again with fresh token |

## Guardrails

- ✅ Never expose tokens in user-facing output
- ✅ Always ask before creating repos or projects
- ✅ Default to public repos
- ✅ Save metadata but never tokens
- ✅ Clear tmp clones after pushing
