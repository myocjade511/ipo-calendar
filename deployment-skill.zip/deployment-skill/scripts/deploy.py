#!/usr/bin/env python3
"""
Deployment Helper — GitHub + Vercel

Usage:
  python deploy.py create-repo --name NAME [--private]
  python deploy.py create-vercel-project --name NAME --team-id ID
  python deploy.py link --repo OWNER/REPO --project-id ID --team-id ID
  python deploy.py push --repo OWNER/REPO --source-dir DIR
  python deploy.py deploy-files --name NAME --files FILE1 FILE2
"""

import os, sys, json, urllib.request, base64

GITHUB_TOKEN = os.environ.get("GITHUB_TOKEN", "")
VERCEL_TOKEN = os.environ.get("VERCEL_TOKEN", "")

def gh(path, method="GET", data=None):
    url = f"https://api.github.com{path}"
    headers = {"Authorization": f"Bearer {GITHUB_TOKEN}", "Accept": "application/vnd.github+json", "User-Agent": "deploy-skill"}
    body = json.dumps(data).encode() if data else None
    req = urllib.request.Request(url, data=body, headers=headers, method=method)
    return json.loads(urllib.request.urlopen(req, timeout=15).read())

def vc(path, method="GET", data=None):
    url = f"https://api.vercel.com{path}"
    headers = {"Authorization": f"Bearer {VERCEL_TOKEN}", "Content-Type": "application/json"}
    body = json.dumps(data).encode() if data else None
    req = urllib.request.Request(url, data=body, headers=headers, method=method)
    return json.loads(urllib.request.urlopen(req, timeout=15).read())

def cmd_create_repo(args):
    name = args.get("name")
    if not name: print("Need --name"); return
    private = args.get("private", False)
    desc = args.get("desc", f"Project: {name}")
    result = gh("/user/repos", "POST", {"name": name, "private": bool(private), "description": desc, "auto_init": True})
    print(f"✅ Repo: {result.get('full_name')}")
    print(f"   URL: {result.get('html_url')}")

def cmd_create_vercel(args):
    name = args.get("name")
    tid = args.get("team_id")
    if not name or not tid: print("Need --name and --team-id"); return
    result = vc(f"/v10/projects?teamId={tid}", "POST", {"name": name, "framework": None})
    print(f"✅ Vercel project: {result.get('name')}")
    print(f"   ID: {result.get('id')}")

def cmd_link(args):
    repo = args.get("repo")
    pid = args.get("project_id")
    tid = args.get("team_id")
    if not repo or not pid or not tid: print("Need --repo, --project-id, --team-id"); return
    result = vc(f"/v10/projects/{pid}/link?teamId={tid}", "POST", {"type": "github", "repo": repo})
    print(f"✅ Linked: {result.get('link',{}).get('type','?')} → {result.get('link',{}).get('repo','?')}")

def main():
    if len(sys.argv) < 2:
        print("Commands: create-repo, create-vercel-project, link, push, deploy-files")
        sys.exit(1)
    
    cmd = sys.argv[1]
    args = {}
    i = 2
    while i < len(sys.argv):
        if sys.argv[i].startswith("--"):
            k = sys.argv[i][2:]
            v = sys.argv[i+1] if i+1 < len(sys.argv) and not sys.argv[i+1].startswith("--") else True
            args[k] = v
            i += 2 if isinstance(v, str) else 1
        else:
            i += 1
    
    cmds = {
        "create-repo": cmd_create_repo,
        "create-vercel-project": cmd_create_vercel,
        "link": cmd_link,
    }
    
    if cmd in cmds:
        cmds[cmd](args)
    else:
        print(f"Unknown command: {cmd}")

if __name__ == "__main__":
    main()
