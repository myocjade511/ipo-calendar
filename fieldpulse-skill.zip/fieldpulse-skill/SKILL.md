---
name: fieldpulse-skill
description: Full FieldPulse CRM API — manage customers, jobs, invoices, estimates, assets, payments, projects, locations, and more via the FieldPulse REST API. 113 endpoints across 26 resource groups.
version: 1.0.0
license: Proprietary
metadata:
  openclaw:
    requires:
      env: ["FIELDPULSE_API_KEY"]
      bins: ["python3"]
    primaryEnv: FIELDPULSE_API_KEY
    emoji: "🔧"
---

# FieldPulse API Skill

Manage field service operations via the FieldPulse REST API — customers, jobs, invoices, estimates, payments, assets, projects, purchase orders, timesheets, and more.

**Base URL:** `https://ywe3crmpll.execute-api.us-east-2.amazonaws.com/stage`

**Auth:** Pass your API key in the `x-api-key` header.

## Setup

1. Get an API key from FieldPulse Support (`support@fieldpulse.com`)
2. Set the env variable:
   ```
   export FIELDPULSE_API_KEY="your-api-key-here"
   ```

## Quick Start

```bash
# List customers
python3 scripts/fieldpulse_client.py list customers

# Get a specific job
python3 scripts/fieldpulse_client.py get jobs 123

# Create an invoice
python3 scripts/fieldpulse_client.py create invoices '{"customer_id":456,"title":"Invoice #1001"}'

# Update invoice status
python3 scripts/fieldpulse_client.py update invoices 789 '{"status":"paid"}'

# Delete an asset
python3 scripts/fieldpulse_client.py delete assets 999

# Search invoices
python3 scripts/fieldpulse_client.py search invoices status_id=3 customer_id=456
```

## Endpoints by Resource

### Customers (`/customers`)
| Method | Path | Description |
|--------|------|-------------|
| GET | `/customers` | List customers (filters: sort_by, sort_dir, search, filter, limit, page) |
| POST | `/customers` | Create customer |
| GET | `/customers/{customerId}` | Get customer by ID (query: filter, with_custom_fields, rel[custom_fields]) |
| PUT | `/customers/{customerId}` | Update customer |
| DELETE | `/customers/{customerId}` | Delete customer |
| GET | `/customers/{customerId}/customer-contact` | List customer contacts |
| POST | `/customers/{customerId}/customer-contact` | Create customer contact |
| GET | `/customers/{customerId}/customer-contact/{contactId}` | Get customer contact |
| PUT | `/customers/{customerId}/customer-contact/{contactId}` | Update customer contact |
| DELETE | `/customers/{customerId}/customer-contact/{contactId}` | Delete customer contact |

### Jobs (`/jobs`)
| Method | Path | Description |
|--------|------|-------------|
| GET | `/jobs` | List jobs (filters: page, limit, search, sort_by, status, customer_id, date_start, date_end) |
| POST | `/jobs` | Create job |
| GET | `/jobs/{jobId}` | Get job by ID (query: with_custom_fields) |
| PUT | `/jobs/{jobId}` | Update job |
| DELETE | `/jobs/{jobId}` | Delete job |
| GET | `/jobs/status-workflows` | List job status workflows |
| GET | `/jobs/status-workflow-statuses` | List job status workflow statuses |
| GET | `/jobs/qb-classes` | Get job QuickBooks classes |

### Invoices (`/invoices`)
| Method | Path | Description |
|--------|------|-------------|
| GET | `/invoices` | List invoices (filters: limit, page, sort_by, status_id, customer_id, rel[public_link]) |
| POST | `/invoices` | Create invoice |
| GET | `/invoices/{invoiceId}` | Get invoice by ID |
| PUT | `/invoices/{invoiceId}` | Update invoice |
| DELETE | `/invoices/{invoiceId}` | Delete invoice |
| PUT | `/invoices/{invoiceId}/price-update` | Update invoice prices |
| GET | `/invoices/status-workflows` | List invoice status workflows |
| GET | `/invoices/statuses` | List invoice statuses |
| GET | `/invoices/qb-classes` | Get invoice QuickBooks classes |

### Estimates (`/estimates`)
| Method | Path | Description |
|--------|------|-------------|
| GET | `/estimates` | List estimates (filters: limit, page, sort_by, status_id, customer_id) |
| POST | `/estimates` | Create estimate |
| GET | `/estimates/{estimateId}` | Get estimate by ID |
| PUT | `/estimates/{estimateId}` | Update estimate |
| DELETE | `/estimates/{estimateId}` | Delete estimate |
| GET | `/estimates/status-workflows` | List estimate status workflows |
| GET | `/estimates/statuses` | List estimate statuses |
| GET | `/estimates/qb-classes` | Get estimate QuickBooks classes |

### Assets (`/assets`)
| Method | Path | Description |
|--------|------|-------------|
| GET | `/assets` | List assets (filters: status, limit, page, sort_by) |
| POST | `/assets` | Create asset |
| GET | `/assets/{id}` | Get asset by ID |
| PUT | `/assets/{id}` | Update asset |
| DELETE | `/assets/{id}` | Delete asset |

### Asset Categories (`/assets-category`)
| Method | Path | Description |
|--------|------|-------------|
| GET | `/assets-category` | List asset categories |
| POST | `/assets-category` | Create asset category |
| GET | `/assets-category/{id}` | Get category by ID |
| PUT | `/assets-category/{id}` | Update category |
| DELETE | `/assets-category/{id}` | Delete category |

### Comments (`/comments`)
| Method | Path | Description |
|--------|------|-------------|
| GET | `/comments` | List comments (filters: limit, page, object_type, object_id) |
| POST | `/comments` | Create comment |
| GET | `/comments/{id}` | Get comment by ID |
| PUT | `/comments/{id}` | Update comment |
| DELETE | `/comments/{id}` | Delete comment |

### Projects (`/projects`)
| Method | Path | Description |
|--------|------|-------------|
| GET | `/projects` | List projects (filters: limit, sort_by, search) |
| POST | `/projects` | Create project |
| GET | `/projects/{projectId}` | Get project by ID |
| PUT | `/projects/{projectId}` | Update project |
| DELETE | `/projects/{projectId}` | Delete project |

### Payments (`/payments`)
| Method | Path | Description |
|--------|------|-------------|
| GET | `/payments` | List payments (filters: limit, page, sort_by, sort_dir, invoice_id) |
| POST | `/payments` | Create payment |
| GET | `/payments/{id}` | Get payment by ID |
| PUT | `/payments/{id}` | Update payment |
| DELETE | `/payments/{id}` | Delete payment |

### Locations (`/locations`)
| Method | Path | Description |
|--------|------|-------------|
| GET | `/locations` | List locations |
| POST | `/locations` | Create location |
| GET | `/locations/{locationId}` | Get location by ID |
| PUT | `/locations/{locationId}` | Update location |
| DELETE | `/locations/{locationId}` | Delete location |

### Purchase Orders (`/purchase-orders`)
| Method | Path | Description |
|--------|------|-------------|
| GET | `/purchase-orders` | List purchase orders |
| POST | `/purchase-orders` | Create purchase order |
| GET | `/purchase-orders/{id}` | Get PO by ID |
| PUT | `/purchase-orders/{id}` | Update PO |
| DELETE | `/purchase-orders/{id}` | Delete PO |

### Timesheets (`/timesheets`)
| Method | Path | Description |
|--------|------|-------------|
| GET | `/timesheets` | List timesheets (filters: limit, user_id, date) |
| POST | `/timesheets` | Create timesheet entry |
| GET | `/timesheets/{id}` | Get timesheet by ID |
| PUT | `/timesheets/{id}` | Update timesheet |
| DELETE | `/timesheets/{id}` | Delete timesheet |

### Tags (`/tags`)
| Method | Path | Description |
|--------|------|-------------|
| GET | `/tags` | List tags (filters: limit, page, object_type) |
| POST | `/tags` | Create tag |
| GET | `/tags/{tagId}` | Get tag by ID |
| PUT | `/tags/{tagId}` | Update tag |
| DELETE | `/tags/{tagId}` | Delete tag |

### Items (`/items`)
| Method | Path | Description |
|--------|------|-------------|
| GET | `/items` | List items (filters: limit, page, calculate_count) |
| POST | `/items` | Create item |
| GET | `/items/{id}` | Get item by ID |
| PUT | `/items/{id}` | Update item |

### Subtasks (`/subtasks`)
| Method | Path | Description |
|--------|------|-------------|
| GET | `/subtasks` | List subtasks |
| POST | `/subtasks` | Create subtask |
| GET | `/subtasks/{id}` | Get subtask by ID |
| PUT | `/subtasks/{id}` | Update subtask |
| DELETE | `/subtasks/{id}` | Delete subtask |

### Custom Fields (`/custom-fields`)
| Method | Path | Description |
|--------|------|-------------|
| GET | `/custom-fields` | List custom fields (filters: limit, object_type) |
| POST | `/custom-fields` | Create custom field |
| GET | `/custom-fields/{customfieldId}` | Get custom field by ID |
| PUT | `/custom-fields/{customfieldId}` | Update custom field |
| DELETE | `/custom-fields/{customfieldId}` | Delete custom field |

### Material Lists (`/material-lists`)
| Method | Path | Description |
|--------|------|-------------|
| GET | `/material-lists` | List material lists |
| POST | `/material-list` | Create material list |
| GET | `/material-list/{id}` | Get material list by ID |
| PUT | `/material-list/{id}` | Update material list |
| DELETE | `/material-list/{id}` | Delete material list |
| POST | `/material-lists/{id}/connect` | Connect material list to entity |
| POST | `/material-lists/{id}/disconnect` | Disconnect material list from entity |
| POST | `/material-lists/{id}/item-connect` | Connect material list item to entity |

### Company Profiles (`/company-profile`)
| Method | Path | Description |
|--------|------|-------------|
| GET | `/company-profile` | List company profiles |
| GET | `/company-profile/{id}` | Get company profile by ID |

### Contracts (`/contracts`)
| Method | Path | Description |
|--------|------|-------------|
| GET | `/contracts` | List contracts |
| GET | `/contracts/{id}` | Get contract by ID |

### Read-only Endpoints
| Method | Path | Description |
|--------|------|-------------|
| GET | `/users` | List company users |
| GET | `/vendors` | List vendors (filters: search, limit, page) |
| GET | `/vendors/{id}` | Get vendor by ID |
| GET | `/teams` | List company teams |
| GET | `/lead-source` | List lead sources |
| GET | `/pipeline-status` | List pipeline statuses |
| GET | `/version` | Get API version |

## Body Examples (Key Resources)

### Create Customer
```json
{
  "name": "Acme Corp",           // required | max:200
  "email": "info@acme.com",      // optional
  "phone": "555-0100",           // optional | max:50
  "address1": "123 Main St",     // optional
  "city": "New York",            // optional
  "state": "NY",                 // optional | max:50
  "zip": "10001",                // optional
  "website": "https://acme.com", // optional
  "customer_type": "residential",// optional | acceptable: residential, commercial
  "tags": ["tag1", "tag2"],      // optional | array
  "pipeline_status_id": 1,       // optional | integer
  "custom_fields": {}            // optional | object: {fieldId: value}
}
```

### Create Job
```json
{
  "title": "HVAC Repair - Acme Corp",  // required | max:200
  "customer_id": 123,                   // required | integer
  "status_id": 1,                       // optional | integer
  "description": "Fix AC unit",         // optional
  "location_id": 456,                   // optional | integer
  "assigned_to": 789,                   // optional | integer (user id)
  "team_id": 101,                       // optional | integer
  "scheduled_date": "2026-06-01",       // optional | date
  "priority": "normal",                 // optional | acceptable: low, normal, high, urgent
  "custom_fields": {}                   // optional | object
}
```

### Create Invoice
```json
{
  "customer_id": 123,               // required | integer
  "title": "Invoice #1001",         // optional | max:200
  "status_id": 1,                   // optional | integer
  "job_id": 456,                    // optional | integer
  "due_date": "2026-06-15",         // optional | date
  "items": [                        // optional | array of invoice items
    {
      "item_id": 789,
      "quantity": 2,
      "rate": 150.00,
      "description": "Service call"
    }
  ],
  "notes": "Payment due upon receipt",  // optional
  "custom_fields": {}                   // optional
}
```

### Create Estimate
```json
{
  "customer_id": 123,               // required | integer
  "title": "Estimate for Kitchen Renovation", // optional | max:200
  "status_id": 1,                   // optional | integer
  "job_id": 456,                    // optional | integer
  "expiration_date": "2026-07-01",  // optional | date
  "items": [                        // optional
    {
      "item_id": 789,
      "quantity": 1,
      "rate": 5000.00
    }
  ],
  "notes": "Valid for 30 days",     // optional
  "custom_fields": {}                // optional
}
```

### Create Asset
```json
{
  "title": "Carrier AC Unit",       // required | max:200
  "status": "installed",            // required | acceptable: uninstalled, installed, retired
  "customer_id": 123,               // nullable | integer
  "asset_category_id": 456,         // nullable | integer
  "manufacturer": "Carrier",        // optional
  "model": "ABC-123",               // optional
  "serial_number": "SN789012",      // optional
  "purchase_date": "2025-01-15",    // optional | date
  "warranty_expiration": "2027-01-15", // optional | date
  "location_id": 789,               // nullable | integer
  "notes": "Annual maintenance required", // optional | max:4000
  "custom_fields": {}               // optional
}
```

### Create Payment
```json
{
  "invoice_id": 456,                // required | integer
  "amount": 2999.99,                // required | decimal
  "payment_method": "credit_card",  // optional | acceptable: credit_card, cash, check, ach, other
  "payment_date": "2026-05-15",     // optional | date
  "reference": "CHK-1001",          // optional | max:200
  "notes": "Final payment"          // optional
}
```

### Create Location
```json
{
  "name": "Main Office",            // optional | max:200
  "address1": "456 Oak Ave",        // required | max:200
  "city": "Chicago",                // optional | max:100
  "state": "IL",                    // optional | max:50
  "zip": "60601",                   // optional | max:20
  "country": "US",                  // optional | max:50
  "latitude": 41.8781,              // optional | decimal
  "longitude": -87.6298,            // optional | decimal
  "customer_id": 123,               // nullable | integer
  "type": "physical"                // optional
}
```

### Create Comment
```json
{
  "text": "Followed up with customer about the issue", // required | max:4000
  "commentable_id": 123,            // optional | integer (entity id)
  "commentable_type": "customer"    // optional | string (entity type)
}
```

### Create Purchase Order
```json
{
  "vendor_id": 456,                 // required | integer
  "status": "pending",              // optional | acceptable: pending, approved, ordered, received, cancelled
  "notes": "Order parts for job #789", // optional
  "items": [                        // optional
    {
      "item_id": 111,
      "quantity": 5,
      "unit_price": 25.00
    }
  ]
}
```

### Create Tag
```json
{
  "name": "VIP Customer",           // required | max:100
  "object_type": "customer",        // optional | acceptable: customer, job, invoice, estimate, asset
  "color": "#FF5733"               // optional
}
```

### Create Custom Field
```json
{
  "title": "Preferred Contact Time", // required | max:200
  "object_type": "customer",         // required | acceptable: customer, job, invoice, estimate, asset
  "field_type": "text",              // required | acceptable: text, textarea, number, date, select, multi_select, checkbox, url
  "options": [],                     // optional | array of strings (for select/multi_select types)
  "is_required": false,              // optional | boolean
  "sort_order": 1                    // optional | integer
}
```

## Rate Limits

- **50 requests per second** per API key
- When exceeded: HTTP 429 with `RateLimit-Reset` header (epoch timestamp of reset)

## Standard Responses

```json
{
  "error": false,
  "response": { ... }
}
```

Error responses include a message field.

## Common Query Parameters

| Param | Type | Description |
|-------|------|-------------|
| `limit` | int | Results per page (default varies) |
| `page` | int | Page number |
| `sort_by` | str | Field to sort by |
| `sort_dir` | str | `asc` or `desc` |
| `search` | str | Search term |
| `filter` | array|obj | Advanced filters |
| `calculate_count` | bool | Include total count |
| `with_custom_fields` | bool | Include custom field values |
| `rel[public_link]` | bool | Include public links |

## Webhooks

Webhook setup must be configured by FieldPulse Support. Payload format:
```json
{
  "trigger": "Event Name",
  "message": "ACTION ON RESOURCE [FOR FIELD_NAME]",
  "data": { ... },
  "company": "FieldPulse_CompanyTitle_CompanyId"
}
```

## Status Codes

| Code | Meaning |
|------|---------|
| 200 | OK |
| 201 | Created |
| 202 | Accepted (auth passed) |
| 400 | Bad request (missing/invalid params) |
| 401 | Unauthorized (missing/invalid API key) |
| 404 | Not found |
| 422 | Auth validation error |
| 429 | Rate limit exceeded |
| 500 | Server error |
