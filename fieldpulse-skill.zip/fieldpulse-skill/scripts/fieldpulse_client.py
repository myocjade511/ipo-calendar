#!/usr/bin/env python3
"""
FieldPulse API Client — generated from official Postman collection

Usage:
  python3 fieldpulse_client.py <action> [params...]

Actions:
  list <resource>             GET list (e.g. "customers", "jobs", "invoices")
  get <resource> <id>         GET by ID
  create <resource> <json>    POST with JSON body
  update <resource> <id> <json>  PUT with JSON body
  delete <resource> <id>      DELETE by ID
  search <resource> <field>=<value>...  GET list with query params

Resources:
  customers, jobs, invoices, estimates, assets, comments,
  projects, payments, locations, tags, subtasks, vendors,
  purchase-orders, timesheets, material-lists, custom-fields,
  assets-category, contracts, company-profile, lead-source,
  pipeline-status, teams, users, items, version

Examples:
  python3 fieldpulse_client.py list customers
  python3 fieldpulse_client.py get customers 123
  python3 fieldpulse_client.py create customers '{"name":"Acme Corp","email":"info@acme.com"}'
  python3 fieldpulse_client.py search invoices status=paid customer_id=456
  python3 fieldpulse_client.py delete assets 456
"""

import os, sys, json, urllib.request, urllib.parse

BASE_URL = os.environ.get("FIELDPULSE_BASE_URL", "https://ywe3crmpll.execute-api.us-east-2.amazonaws.com/stage")
API_KEY = os.environ.get("FIELDPULSE_API_KEY", "")

def _req(method, path, body=None, params=None):
    url = f"{BASE_URL}{path}"
    if params:
        qs = urllib.parse.urlencode(params, doseq=True)
        url = f"{url}?{qs}"
    
    headers = {
        "x-api-key": API_KEY,
        "Accept": "application/json",
    }
    if body:
        headers["Content-Type"] = "application/json"
        data = json.dumps(body).encode()
    else:
        data = None
    
    req = urllib.request.Request(url, data=data, headers=headers, method=method)
    try:
        with urllib.request.urlopen(req, timeout=30) as resp:
            return {
                "status": resp.status,
                "data": json.loads(resp.read().decode())
            }
    except urllib.error.HTTPError as e:
        error_body = e.read().decode() if e.fp else str(e)
        try:
            error_body = json.loads(error_body)
        except:
            pass
        return {
            "status": e.code,
            "error": error_body
        }

def resource_path(name):
    """Convert resource name to API path."""
    name = name.strip().lower()
    mapping = {
        'assets': 'assets',
        'asset-categories': 'assets-category',
        'asset-category': 'assets-category',
        'comments': 'comments',
        'company-profiles': 'company-profile',
        'company-profile': 'company-profile',
        'contracts': 'contracts',
        'customers': 'customers',
        'custom-fields': 'custom-fields',
        'customfield': 'custom-fields',
        'customfields': 'custom-fields',
        'estimates': 'estimates',
        'invoices': 'invoices',
        'items': 'items',
        'jobs': 'jobs',
        'lead-sources': 'lead-source',
        'leadsource': 'lead-source',
        'lead-source': 'lead-source',
        'locations': 'locations',
        'material-lists': 'material-lists',
        'materiallist': 'material-lists',
        'material-list': 'material-lists',
        'payments': 'payments',
        'pipeline-status': 'pipeline-status',
        'projects': 'projects',
        'purchase-orders': 'purchase-orders',
        'purchaseorder': 'purchase-orders',
        'purchase-order': 'purchase-orders',
        'subtasks': 'subtasks',
        'tags': 'tags',
        'teams': 'teams',
        'timesheets': 'timesheets',
        'users': 'users',
        'vendors': 'vendors',
        'version': 'version',
    }
    return mapping.get(name, name)

def cmd_list(args):
    """GET list endpoint."""
    resource = args[0] if args else 'customers'
    path = f"/{resource_path(resource)}"
    # Parse optional query params from remaining args
    params = {}
    for arg in args[1:]:
        if '=' in arg:
            k, v = arg.split('=', 1)
            params[k] = v
    
    result = _req("GET", path, params=params or None)
    return json.dumps(result, indent=2)

def cmd_get(args):
    """GET by ID."""
    if len(args) < 2:
        return "Usage: get <resource> <id>"
    resource = resource_path(args[0])
    obj_id = args[1]
    path = f"/{resource}/{obj_id}"
    result = _req("GET", path)
    return json.dumps(result, indent=2)

def cmd_create(args):
    """POST create."""
    if len(args) < 2:
        return "Usage: create <resource> <json_body>"
    resource = resource_path(args[0])
    try:
        body = json.loads(args[1])
    except:
        return f"Invalid JSON: {args[1]}"
    path = f"/{resource}"
    result = _req("POST", path, body=body)
    return json.dumps(result, indent=2)

def cmd_update(args):
    """PUT update."""
    if len(args) < 3:
        return "Usage: update <resource> <id> <json_body>"
    resource = resource_path(args[0])
    obj_id = args[1]
    try:
        body = json.loads(args[2])
    except:
        return f"Invalid JSON: {args[2]}"
    path = f"/{resource}/{obj_id}"
    result = _req("PUT", path, body=body)
    return json.dumps(result, indent=2)

def cmd_delete(args):
    """DELETE by ID."""
    if len(args) < 2:
        return "Usage: delete <resource> <id>"
    resource = resource_path(args[0])
    obj_id = args[1]
    path = f"/{resource}/{obj_id}"
    result = _req("DELETE", path)
    return json.dumps(result, indent=2)

def cmd_search(args):
    """GET list with query params."""
    if not args:
        return "Usage: search <resource> key=value [key=value...]"
    resource = resource_path(args[0])
    params = {}
    for arg in args[1:]:
        if '=' in arg:
            k, v = arg.split('=', 1)
            params[k] = v
    if not params:
        params = {"search": args[1]} if len(args) > 1 else None
    path = f"/{resource}"
    result = _req("GET", path, params=params)
    return json.dumps(result, indent=2)

def cmd_help():
    examples = [
        '',
        '  list customers',
        '  list jobs ?limit=10&page=1',
        '  get customers 123',
        '  create customers \'{"name":"Test Corp","email":"test@corp.com"}\'',
        '  update invoices 456 \'{"status":"paid"}\'',
        '  delete assets 789',
        '  search invoices status=paid customer_id=456',
    ]
    return '\n'.join(examples)

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print(__doc__)
        sys.exit(1)
    
    action = sys.argv[1]
    args = sys.argv[2:]
    
    actions = {
        'list': cmd_list,
        'get': cmd_get,
        'create': cmd_create,
        'update': cmd_update,
        'delete': cmd_delete,
        'search': cmd_search,
        'help': cmd_help,
    }
    
    if action not in actions:
        print(f"Unknown action: {action}")
        print(f"Available: {', '.join(actions.keys())}")
        sys.exit(1)
    
    result = actions[action](args)
    print(result)
